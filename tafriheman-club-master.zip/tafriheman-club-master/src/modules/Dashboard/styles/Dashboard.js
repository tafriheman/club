export default theme => ({
  header: {
    width: '100%',
    marignBottom: '20px'
  },
});