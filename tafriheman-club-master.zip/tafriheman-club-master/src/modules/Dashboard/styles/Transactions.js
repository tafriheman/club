export default theme =>({
  header: {
    width: '100%',
    marignBottom: '20px'
  },
  paperContainer: {
    width: '100%'
  },
  paperRoot: {
    marginTop: '30px',
    marginBottom: '20px'
  }
});