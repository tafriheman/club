export default theme => ({
  listItem: {
    textAlign: 'right'
  },
  link: {
    textDecoration: 'none',
    color: '#000',
  },
  // paperRoot: {
  //   marginTop: '4px',
  //   borderRadius: 0,
  //   padding: '10px'
  // },
  // singleLink: {
  //   display: 'block',
  //   width: '100%',
  //   textDecoration: 'none',
  //   color: '#000'
  // },
  // expantionDetail: {
  //   dispaly: 'flex',
  //   flexDirection: 'column'
  // },
  // expantionPanelSummaryRoot: {
  //   paddingRight: '10px',
  // },
  // expandIcon: {
  //   right: 'auto',
  //   left: '8px',
  //   paddingLeft: 0
  // },
  // '@global': {
  //   "[class*='MuiExpansionPanel-expanded-']": {
  //     marginBottom: 0,
  //     marginTop: 0
  //   }
  // }
});