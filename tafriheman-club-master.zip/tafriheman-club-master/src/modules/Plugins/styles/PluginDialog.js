export default theme => ({
  paper: {
    width: '600px',
  },
  dialogContent: {
    padding: 0
  },
  pluginImage: {
    width: '100%',
    height: '200px'
  },
  infoContainer: {
    padding: '5px 10px' 
  }
})