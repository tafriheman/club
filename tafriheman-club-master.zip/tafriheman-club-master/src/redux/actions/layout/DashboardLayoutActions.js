import { LAYOUT_DASHBOARD_LAYOUT_TOGGLE_DRAWER } from '../../types';

export const layoutDashboardLayoutToggleNavbar = () => {
  return {
    type: LAYOUT_DASHBOARD_LAYOUT_TOGGLE_DRAWER
  }
}